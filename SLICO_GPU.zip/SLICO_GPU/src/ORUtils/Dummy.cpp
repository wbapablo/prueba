// Copyright 2014-2015 Isis Innovation Limited and the authors of InfiniTAM

void dummy_with_external_linkage() {}

